# Gizlilik Politikası

Bu eklenti, kullanıcı verilerini toplamaz, saklamaz veya paylaşmaz. Eklenti yalnızca kullanıcıların Türkçe karakterleri panoya kopyalamasına olanak tanır.

## Veriler
- **Toplanan Veriler:** Hiçbir veri toplanmaz.
- **Paylaşılan Veriler:** Hiçbir veri üçüncü taraflarla paylaşılmaz.

## İzinler
Bu eklenti yalnızca panoya kopyalama işlemi için `clipboardWrite` iznini kullanır. Bu izin, yalnızca kullanıcı tarafından başlatılan kopyalama işlemleri sırasında devreye girer ve başka bir amaç için kullanılmaz.

Herhangi bir sorunuz olursa, bizimle iletişime geçebilirsiniz.
